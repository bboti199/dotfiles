This is a bundled copy of [gitstatus](https://github.com/romkatv/gitstatus) ZSH plugin.

